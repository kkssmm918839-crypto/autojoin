(() => {
  'use strict';

  const DEFAULTS = { targetUserId: '', enabled: false };
  let api = null;
  let bound = false;
  let lastTargetChannelId = null;
  let lastMove = 0;

  function logError(error) {
    try { api?.logger?.warn?.('VC Follow: ' + String(error)); } catch (_) {}
  }
  function toast(message) {
    try {
      const actions = revenge.discord.actions.ToastActionCreators;
      actions.open({ key: 'vc-follow-notice', content: message });
    } catch (_) { try { api?.logger?.log?.('VC Follow: ' + message); } catch (_) {} }
  }
  function settings() {
    return { ...DEFAULTS, ...(api?.jsonStorage?.cache || {}) };
  }
  function save(next) {
    if (!api) return;
    api.jsonStorage.set({ ...settings(), ...next });
  }
  function normalizeUserId(input) {
    const str = String(input || '').trim();
    const match = str.match(/^(?:<@!?)?(\d{15,22})>?$/);
    return match ? match[1] : null;
  }
  function getCurrentUserId() {
    try { return revenge.discord.flux.Stores.UserStore.getCurrentUser()?.id || null; }
    catch (_) { return null; }
  }
  function getChannel(id) {
    try { return revenge.discord.flux.Stores.ChannelStore.getChannel(id) || null; }
    catch (_) { return null; }
  }
  function getOwnVoiceChannel() {
    try {
      const stores = revenge.discord.flux.Stores;
      return stores.SelectedChannelStore?.getVoiceChannelId?.() ||
        stores.VoiceStateStore?.getVoiceChannelId?.() || null;
    } catch (_) { return null; }
  }
  function getTargetVoice(userId, guildId) {
    try {
      const store = revenge.discord.flux.Stores.VoiceStateStore;
      const state = store?.getVoiceStateForUser?.(guildId, userId);
      return state?.channelId || state?.channel_id || null;
    } catch (_) { return null; }
  }
  function findModule(...props) {
    try {
      const f = revenge.modules.finders;
      const filter = revenge.modules.filters?.withProps || revenge.modules.finders.filters?.withProps;
      if (!filter) return null;
      const [exports, id] = f.lookupModule(filter(...props));
      return id === undefined ? null : exports;
    } catch (error) { logError(error); return null; }
  }
  function canConnect(channel) {
    if (!channel || !channel.guild_id) return false;
    // Discord ultimately enforces connection authorization. This check is
    // extra defense when its PermissionStore is available.
    try {
      const store = revenge.discord.flux.Stores.PermissionStore;
      const permissions = findModule('Permissions')?.Permissions;
      const flag = permissions?.CONNECT;
      if (store?.can && flag !== undefined && !store.can(flag, channel)) return false;
    } catch (_) {}
    return true;
  }
  function voiceSwitch(channelId) {
    const module = findModule('selectVoiceChannel');
    if (!module || typeof module.selectVoiceChannel !== 'function') {
      toast('VC Follow: voice switch API not found on this Discord build.');
      return false;
    }
    try {
      module.selectVoiceChannel(channelId);
      return true;
    } catch (error) {
      logError(error);
      toast('VC Follow: could not switch VC.');
      return false;
    }
  }
  function followUser(userId) {
    const id = normalizeUserId(userId);
    if (!id) return 'Enter a valid Discord user ID or mention.';
    if (id === getCurrentUserId()) return 'You cannot follow yourself.';
    lastTargetChannelId = null;
    save({ enabled: true, targetUserId: id });
    toast('VC Follow enabled for ' + id);
    return 'Following ' + id + '. Join a VC in the same server to auto-follow.';
  }
  function unfollow() {
    lastTargetChannelId = null;
    save({ enabled: false, targetUserId: '' });
    toast('VC Follow disabled');
    return 'Stopped following.';
  }
  function processVoiceState(userId, guildId, channelId) {
    const data = settings();
    if (!data.enabled || !data.targetUserId || userId !== data.targetUserId) return;
    const mine = getOwnVoiceChannel();
    if (!mine || !channelId || mine === channelId) return;
    const mineChannel = getChannel(mine);
    const destination = getChannel(channelId);
    if (!mineChannel || !destination || !guildId ||
        String(mineChannel.guild_id) !== String(guildId) ||
        String(destination.guild_id) !== String(guildId)) return;
    if (!canConnect(destination)) return;
    if (lastTargetChannelId === channelId) return;
    const now = Date.now();
    if (now - lastMove < 1000) return; // suppress event bursts
    if (voiceSwitch(channelId)) {
      lastMove = now;
      lastTargetChannelId = channelId;
    }
  }
  function inspectEvent(payload) {
    if (!payload || !settings().enabled) return;
    const states = payload.voiceStates || payload.voice_states ||
      (payload.voiceState ? [payload.voiceState] : [payload]);
    if (!Array.isArray(states)) return;
    for (const state of states) {
      if (!state) continue;
      const uid = String(state.userId || state.user_id || state.user?.id || '');
      const guildId = state.guildId || state.guild_id || payload.guildId || payload.guild_id;
      const channelId = state.channelId === null || state.channel_id === null
        ? null : (state.channelId || state.channel_id);
      processVoiceState(uid, guildId, channelId);
    }
  }
  function commandTarget(args) {
    const item = Array.isArray(args) ? args[0] : args;
    const value = item?.value ?? item?.user?.id ?? item?.id ?? item;
    return normalizeUserId(typeof value === 'object' ? (value?.id || value?.value) : value);
  }
  function command(name, description, opts, execute) {
    return {
      name, displayName: name, description, displayDescription: description,
      type: 1, inputType: 0, applicationId: '-1',
      options: opts, execute,
    };
  }
  function tryRegisterCommands(cleanup) {
    const mod = findModule('getBuiltInCommands');
    const after = revenge.patcher?.after;
    if (!mod || typeof mod.getBuiltInCommands !== 'function' || !after) {
      toast('VC Follow: /vcf commands unavailable; use plugin settings.');
      return;
    }
    const options = [{ name: 'user', displayName: 'user', description: 'Friend to follow',
      displayDescription: 'Friend to follow', type: 6, required: true }];
    const commands = [
      command('vcf', 'Follow a friend in voice channels', options, args => {
        const id = commandTarget(args);
        toast(followUser(id));
      }),
      command('vcunf', 'Stop following a voice channel', [], () => { unfollow(); }),
    ];
    try {
      const builtins = mod.getBuiltInCommands(1, true, false);
      const ids = (Array.isArray(builtins) ? builtins : []).map(c => Number(c.id))
        .filter(Number.isFinite);
      const min = ids.length ? Math.min(...ids) : -100;
      commands.forEach((c, i) => { c.id = String(min - i - 1); });
      cleanup(after(mod, 'getBuiltInCommands', (args, ret) => {
        if (args[0] !== 1 || !Array.isArray(ret)) return ret;
        return ret.concat(commands);
      }));
    } catch (error) { logError(error); }
  }
  function tryProfileActions(cleanup) {
    // Undocumented Discord API, only patch when the module has a compatible
    // action-list shape. If absent, the settings view remains fully usable.
    const after = revenge.patcher?.after;
    if (!after) return;
    const names = ['getUserProfileActions', 'getUserProfileActionItems'];
    for (const name of names) {
      const mod = findModule(name);
      if (!mod || typeof mod[name] !== 'function') continue;
      try {
        cleanup(after(mod, name, (args, ret) => {
          if (!Array.isArray(ret)) return ret;
          const context = args[0];
          const userId = normalizeUserId(context?.user?.id || context?.userId || context?.id);
          if (!userId || userId === getCurrentUserId()) return ret;
          if (ret.some(action => action?.id === 'vc-follow-toggle')) return ret;
          const following = settings().enabled && settings().targetUserId === userId;
          return ret.concat([{
            id: 'vc-follow-toggle',
            label: following ? 'Unfollow VC' : 'Follow VC',
            text: following ? 'Unfollow VC' : 'Follow VC',
            onPress: () => following ? unfollow() : followUser(userId),
            action: () => following ? unfollow() : followUser(userId),
          }]);
        }));
        return;
      } catch (error) { logError(error); }
    }
  }
  function SettingsComponent({ api: componentApi }) {
    const React = revenge.react.React;
    const RN = revenge.react.ReactNative;
    const current = componentApi.jsonStorage.use() || DEFAULTS;
    const [input, setInput] = React.useState(current.targetUserId || '');
    const [notice, setNotice] = React.useState('');
    const e = React.createElement;
    const label = (content, style) => e(RN.Text, { style: {
      color: '#eeeeee', fontSize: 15, marginBottom: 10, ...style,
    } }, content);
    const button = (name, action, background) => e(RN.Pressable, {
      onPress: action, style: { backgroundColor: background, padding: 12,
        borderRadius: 9, marginTop: 12, alignItems: 'center' },
    }, e(RN.Text, { style: { color: '#ffffff', fontWeight: 'bold' } }, name));
    return e(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 20 } },
      label('VC Follow', { fontSize: 20, fontWeight: 'bold' }),
      label('Follow a friend automatically when they move between voice channels in your current server.'),
      label('Status: ' + (current.enabled ? 'Following ' + current.targetUserId : 'Stopped')),
      label('Friend Discord user ID (15–22 digits)'),
      e(RN.TextInput, { value: input, onChangeText: setInput,
        placeholder: '123456789012345678', placeholderTextColor: '#aaaaaa',
        keyboardType: 'numeric', autoCapitalize: 'none',
        style: { backgroundColor: '#292b30', color: '#ffffff',
          borderRadius: 8, padding: 12, fontSize: 15 } }),
      button('Follow VC', () => setNotice(followUser(input)), '#5865f2'),
      button('Unfollow VC', () => { setNotice(unfollow()); setInput(''); }, '#4a4c54'),
      label(notice, { marginTop: 12, color: '#bbbbee' }),
      label('Commands (experimental): /vcf @user and /vcunf.\nProfile action (experimental).',
        { marginTop: 8, fontSize: 12, color: '#aaaaaa' })
    );
  }
  return {
    jsonStorage: { load: true, default: DEFAULTS },
    start(startApi) {
      api = startApi;
      bound = true;
      lastTargetChannelId = null;
      lastMove = 0;
      const { cleanup } = startApi;
      try {
        const on = revenge.discord.flux.onFluxEventDispatched;
        cleanup(on('VOICE_STATE_UPDATES', payload => { inspectEvent(payload); return payload; }));
        cleanup(on('VOICE_STATE_UPDATE', payload => { inspectEvent(payload); return payload; }));
      } catch (error) { logError(error); }
      tryRegisterCommands(cleanup);
      tryProfileActions(cleanup);
      cleanup(() => { api = null; bound = false; lastTargetChannelId = null; });
      startApi.logger?.log?.('VC Follow started');
    },
    SettingsComponent,
  };
})()
